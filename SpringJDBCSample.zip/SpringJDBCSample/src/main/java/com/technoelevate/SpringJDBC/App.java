package com.technoelevate.SpringJDBC;

public class App {

	public static void main(String[] args) {
		
	}

}
