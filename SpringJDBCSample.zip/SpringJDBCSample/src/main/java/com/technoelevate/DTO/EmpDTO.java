package com.technoelevate.DTO;

import lombok.Data;

	@Data
	public class EmpDTO {
		private String empid;
		private String empname;
		private String passkey;
}
